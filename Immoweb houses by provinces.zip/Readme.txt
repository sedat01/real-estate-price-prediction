Links are scraped with selenium from the live immoweb.be/en website, not from the site map.
All ads are active by the time of gathering

This folder includes the data gathered from the links by provinces.
The "from_json..." files contain the data from the script only
The "from_tables..." files contain the data from the visible description of the property.
The "data_all..." files contain the two beforementioned files concatanated along the columns.

The data is unfiltered and  do dirty. You should do own cleaning.
Success!

The data is gathered on 12/10/2022.

#   ______   _______  _______  _______  ______   _______ 
#  (  ___ \ (  ____ \(  ____ \(  ___  )(  __  \ (  ____ \
#  | (   ) )| (    \/| (    \/| (   ) || (  \  )| (    \/
#  | (__/ / | (__    | |      | |   | || |   ) || (__    
#  |  __ (  |  __)   | |      | |   | || |   | ||  __)   
#  | (  \ \ | (      | |      | |   | || |   ) || (      
#  | )___) )| (____/\| (____/\| (___) || (__/  )| (____/\
#  |/ \___/ (_______/(_______/(_______)(______/ (_______/
#                                                        
#   _______  _______  _______  _______                   
#  / ___   )(  __   )/ ___   )/ ___   )                  
#  \/   )  || (  )  |\/   )  |\/   )  |                  
#      /   )| | /   |    /   )    /   )                  
#    _/   / | (/ /) |  _/   /   _/   /                   
#   /   _/  |   / | | /   _/   /   _/                    
#  (   (__/\|  (__) |(   (__/\(   (__/\                  
#  \_______/(_______)\_______/\_______/                  
#                                                      